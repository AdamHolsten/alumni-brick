# custom-select-dropdown

This project is demonstration how to create custom select dropdown using HTML, CSS and JavaScript. Whole implementation is described in blog post [How to Create a Custom Select Dropdown using HTML, CSS and JavaScript](https://andrejgajdos.com/custom-select-dropdown/)
